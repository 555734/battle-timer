package com.example.runnergod;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PointF;
import android.graphics.RectF;
import android.os.SystemClock;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class GameView extends View {
    private static final float PLAYER_W = 48f;
    private static final float PLAYER_H = 62f;
    private static final float GRAVITY = 1750f;
    private static final float MOVE_SPEED = 330f;
    private static final float JUMP_SPEED = -760f;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final SparseArray<PointF> touches = new SparseArray<>();
    private final List<Platform> platforms = new ArrayList<>();
    private final List<Enemy> enemies = new ArrayList<>();
    private final List<Crystal> crystals = new ArrayList<>();

    private int viewW;
    private int viewH;
    private float cameraX;
    private float playerX;
    private float playerY;
    private float playerVX;
    private float playerVY;
    private boolean onGround;
    private boolean previousJumpPressed;
    private int deaths;
    private float godEnergy = 100f;
    private long runStartMs;
    private long lastFrameMs;

    private GameState state = GameState.MENU;
    private GodMode godMode = GodMode.PLACE;
    private int draggingPointer = -1;
    private Platform draggingPlatform;
    private float dragOffsetX;
    private float dragOffsetY;

    private final RectF startButton = new RectF();
    private final RectF restartButton = new RectF();
    private final RectF modePlace = new RectF();
    private final RectF modeMove = new RectF();
    private final RectF modeFreeze = new RectF();

    private final float goalX = 3380f;

    public GameView(Context context) {
        super(context);
        setBackgroundColor(Color.rgb(15, 31, 55));
        setFocusable(true);
        lastFrameMs = SystemClock.elapsedRealtime();
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        viewW = w;
        viewH = h;
        startButton.set(w * 0.39f, h * 0.64f, w * 0.61f, h * 0.80f);
        restartButton.set(w * 0.39f, h * 0.68f, w * 0.61f, h * 0.83f);

        float bw = Math.max(130f, w * 0.11f);
        float gap = 10f;
        float right = w - 18f;
        modeFreeze.set(right - bw, 18f, right, 82f);
        modeMove.set(right - bw * 2f - gap, 18f, right - bw - gap, 82f);
        modePlace.set(right - bw * 3f - gap * 2f, 18f, right - bw * 2f - gap * 2f, 82f);

        resetLevel();
    }

    private void resetLevel() {
        if (viewW <= 0 || viewH <= 0) return;
        platforms.clear();
        enemies.clear();
        crystals.clear();
        touches.clear();

        float ground = viewH * 0.72f;
        addPlatform(-100, ground, 620, viewH - ground + 120, false);
        addPlatform(760, ground - 40, 360, 50, false);
        addPlatform(1240, ground - 145, 270, 48, false);
        addPlatform(1640, ground - 10, 420, 52, false);
        addPlatform(2210, ground - 190, 300, 50, false);
        addPlatform(2660, ground - 45, 310, 50, false);
        addPlatform(3110, ground - 105, 500, 55, false);

        addPlatform(520, ground - 180, 145, 28, false);
        addPlatform(1130, ground - 310, 150, 28, false);
        addPlatform(1940, ground - 280, 150, 28, false);
        addPlatform(2880, ground - 290, 160, 28, false);

        enemies.add(new Enemy(900, ground - 92, 820, 1060));
        enemies.add(new Enemy(1780, ground - 62, 1690, 1990));
        enemies.add(new Enemy(2330, ground - 242, 2240, 2460));
        enemies.add(new Enemy(2780, ground - 97, 2700, 2910));

        crystals.add(new Crystal(590, ground - 235));
        crystals.add(new Crystal(1370, ground - 205));
        crystals.add(new Crystal(2020, ground - 338));
        crystals.add(new Crystal(2970, ground - 350));

        playerX = 120;
        playerY = ground - PLAYER_H;
        playerVX = 0;
        playerVY = 0;
        cameraX = 0;
        onGround = false;
        deaths = 0;
        godEnergy = 100f;
        draggingPointer = -1;
        draggingPlatform = null;
        godMode = GodMode.PLACE;
        previousJumpPressed = false;
        runStartMs = SystemClock.elapsedRealtime();
        lastFrameMs = runStartMs;
    }

    private void addPlatform(float x, float y, float w, float h, boolean created) {
        platforms.add(new Platform(x, y, w, h, created));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        long now = SystemClock.elapsedRealtime();
        float dt = Math.min(0.033f, Math.max(0.001f, (now - lastFrameMs) / 1000f));
        lastFrameMs = now;

        if (state == GameState.PLAYING) {
            update(dt);
        }

        drawBackground(canvas);
        if (state == GameState.MENU) {
            drawMenu(canvas);
        } else {
            drawWorld(canvas);
            drawHud(canvas);
            if (state == GameState.WIN) drawWin(canvas);
        }

        postInvalidateOnAnimation();
    }

    private void update(float dt) {
        godEnergy = Math.min(100f, godEnergy + 7.5f * dt);

        boolean left = false;
        boolean right = false;
        boolean jump = false;
        for (int i = 0; i < touches.size(); i++) {
            PointF p = touches.valueAt(i);
            if (p.y > viewH - 165f) {
                if (p.x < 150f) left = true;
                else if (p.x < 300f) right = true;
                else if (p.x > viewW - 210f) jump = true;
            }
        }

        if (left == right) playerVX = 0;
        else playerVX = left ? -MOVE_SPEED : MOVE_SPEED;

        if (jump && !previousJumpPressed && onGround) {
            playerVY = JUMP_SPEED;
            onGround = false;
        }
        previousJumpPressed = jump;

        float oldY = playerY;
        playerX += playerVX * dt;
        if (playerX < 0) playerX = 0;
        playerVY += GRAVITY * dt;
        playerY += playerVY * dt;
        onGround = false;

        RectF playerRect = new RectF(playerX, playerY, playerX + PLAYER_W, playerY + PLAYER_H);
        float oldBottom = oldY + PLAYER_H;
        if (playerVY >= 0) {
            Platform best = null;
            float bestTop = Float.MAX_VALUE;
            for (Platform p : platforms) {
                if (playerRect.right > p.x + 7 && playerRect.left < p.x + p.w - 7) {
                    if (oldBottom <= p.y + 10 && playerRect.bottom >= p.y && p.y < bestTop) {
                        best = p;
                        bestTop = p.y;
                    }
                }
            }
            if (best != null) {
                playerY = best.y - PLAYER_H;
                playerVY = 0;
                onGround = true;
                playerRect.set(playerX, playerY, playerX + PLAYER_W, playerY + PLAYER_H);
            }
        }

        for (Enemy e : enemies) {
            e.update(dt);
            RectF er = new RectF(e.x - 24, e.y - 24, e.x + 24, e.y + 24);
            if (RectF.intersects(playerRect, er) && e.freeze <= 0) {
                respawn();
                break;
            }
        }

        Iterator<Crystal> it = crystals.iterator();
        while (it.hasNext()) {
            Crystal c = it.next();
            float dx = (playerX + PLAYER_W / 2f) - c.x;
            float dy = (playerY + PLAYER_H / 2f) - c.y;
            if (dx * dx + dy * dy < 42f * 42f) {
                godEnergy = Math.min(100f, godEnergy + 28f);
                it.remove();
            }
        }

        if (playerY > viewH + 180) respawn();
        if (playerX + PLAYER_W > goalX) state = GameState.WIN;

        float targetCamera = Math.max(0, playerX - viewW * 0.34f);
        cameraX += (targetCamera - cameraX) * Math.min(1f, dt * 5f);
    }

    private void respawn() {
        deaths++;
        float ground = viewH * 0.72f;
        float[] checkpoints = {120, 820, 1660, 2680};
        float spawn = 120;
        for (float cp : checkpoints) if (playerX > cp + 220) spawn = cp;
        playerX = spawn;
        playerY = ground - PLAYER_H - 120;
        playerVX = 0;
        playerVY = 0;
        godEnergy = Math.min(100, godEnergy + 18);
    }

    private void drawBackground(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(21, 43, 76));
        c.drawRect(0, 0, viewW, viewH, paint);

        paint.setColor(Color.rgb(35, 77, 115));
        for (int i = 0; i < 7; i++) {
            float x = (i * 310f - (cameraX * 0.14f) % 310f) - 80f;
            float peak = viewH * (0.35f + (i % 3) * 0.05f);
            path.reset();
            path.moveTo(x, viewH * 0.70f);
            path.lineTo(x + 170, peak);
            path.lineTo(x + 340, viewH * 0.70f);
            path.close();
            c.drawPath(path, paint);
        }

        paint.setColor(Color.rgb(244, 216, 123));
        c.drawCircle(viewW * 0.19f, viewH * 0.20f, Math.max(24f, viewH * 0.055f), paint);
    }

    private void drawWorld(Canvas c) {
        float ground = viewH * 0.72f;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.rgb(16, 52, 66));
        c.drawRect(0, ground + 40, viewW, viewH, paint);

        for (Platform p : platforms) {
            float sx = p.x - cameraX;
            if (sx + p.w < -100 || sx > viewW + 100) continue;
            if (p.created) {
                paint.setColor(Color.argb(210, 67, 214, 255));
                c.drawRoundRect(sx, p.y, sx + p.w, p.y + p.h, 12, 12, paint);
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(4);
                paint.setColor(Color.WHITE);
                c.drawRoundRect(sx, p.y, sx + p.w, p.y + p.h, 12, 12, paint);
                paint.setStyle(Paint.Style.FILL);
            } else {
                paint.setColor(Color.rgb(76, 107, 74));
                c.drawRoundRect(sx, p.y, sx + p.w, p.y + p.h, 8, 8, paint);
                paint.setColor(Color.rgb(130, 158, 94));
                c.drawRect(sx, p.y, sx + p.w, p.y + Math.min(10, p.h), paint);
            }
        }

        for (Crystal crystal : crystals) {
            float sx = crystal.x - cameraX;
            if (sx < -60 || sx > viewW + 60) continue;
            paint.setColor(Color.rgb(84, 222, 255));
            path.reset();
            path.moveTo(sx, crystal.y - 22);
            path.lineTo(sx + 15, crystal.y);
            path.lineTo(sx, crystal.y + 22);
            path.lineTo(sx - 15, crystal.y);
            path.close();
            c.drawPath(path, paint);
        }

        for (Enemy e : enemies) {
            float sx = e.x - cameraX;
            if (sx < -80 || sx > viewW + 80) continue;
            paint.setColor(e.freeze > 0 ? Color.rgb(116, 216, 255) : Color.rgb(231, 79, 90));
            c.drawCircle(sx, e.y, 25, paint);
            paint.setColor(Color.WHITE);
            c.drawCircle(sx - 8, e.y - 5, 5, paint);
            c.drawCircle(sx + 8, e.y - 5, 5, paint);
            paint.setColor(Color.rgb(28, 37, 52));
            c.drawCircle(sx - 8, e.y - 5, 2.6f, paint);
            c.drawCircle(sx + 8, e.y - 5, 2.6f, paint);
            if (e.freeze > 0) {
                paint.setStyle(Paint.Style.STROKE);
                paint.setStrokeWidth(4);
                paint.setColor(Color.rgb(189, 244, 255));
                c.drawCircle(sx, e.y, 35, paint);
                paint.setStyle(Paint.Style.FILL);
            }
        }

        float gx = goalX - cameraX;
        if (gx > -100 && gx < viewW + 100) {
            paint.setColor(Color.rgb(230, 230, 220));
            c.drawRect(gx, ground - 220, gx + 10, ground - 35, paint);
            paint.setColor(Color.rgb(255, 196, 59));
            path.reset();
            path.moveTo(gx + 10, ground - 220);
            path.lineTo(gx + 105, ground - 190);
            path.lineTo(gx + 10, ground - 160);
            path.close();
            c.drawPath(path, paint);
        }

        drawPlayer(c, playerX - cameraX, playerY);
    }

    private void drawPlayer(Canvas c, float x, float y) {
        paint.setColor(Color.rgb(56, 142, 255));
        c.drawRoundRect(x + 6, y + 18, x + PLAYER_W - 6, y + PLAYER_H, 12, 12, paint);
        paint.setColor(Color.rgb(255, 224, 188));
        c.drawCircle(x + PLAYER_W / 2f, y + 17, 16, paint);
        paint.setColor(Color.rgb(38, 73, 116));
        c.drawRect(x + 7, y + 4, x + PLAYER_W - 3, y + 13, paint);
        paint.setColor(Color.WHITE);
        c.drawCircle(x + 29, y + 17, 3.5f, paint);
    }

    private void drawHud(Canvas c) {
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(190, 7, 20, 36));
        c.drawRoundRect(14, 14, 330, 100, 14, 14, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(25);
        paint.setFakeBoldText(true);
        c.drawText("1P RUNNER", 30, 44, paint);
        paint.setTextSize(18);
        paint.setFakeBoldText(false);
        c.drawText("←  →  JUMP", 30, 74, paint);
        c.drawText("Deaths: " + deaths, 185, 74, paint);

        drawModeButton(c, modePlace, "足場", godMode == GodMode.PLACE);
        drawModeButton(c, modeMove, "移動", godMode == GodMode.MOVE);
        drawModeButton(c, modeFreeze, "停止", godMode == GodMode.FREEZE);

        float barW = Math.min(410f, viewW * 0.34f);
        float bx = viewW / 2f - barW / 2f;
        float by = 22;
        paint.setColor(Color.argb(190, 7, 20, 36));
        c.drawRoundRect(bx - 12, by - 8, bx + barW + 12, by + 48, 14, 14, paint);
        paint.setColor(Color.rgb(45, 62, 78));
        c.drawRoundRect(bx, by + 12, bx + barW, by + 34, 11, 11, paint);
        paint.setColor(Color.rgb(59, 205, 255));
        c.drawRoundRect(bx, by + 12, bx + barW * godEnergy / 100f, by + 34, 11, 11, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(17);
        paint.setFakeBoldText(true);
        c.drawText("2P 神力 " + Math.round(godEnergy) + "/100", bx + 8, by + 8, paint);
        paint.setFakeBoldText(false);

        // Runner touch controls.
        paint.setColor(Color.argb(105, 255, 255, 255));
        c.drawRoundRect(20, viewH - 145, 135, viewH - 25, 28, 28, paint);
        c.drawRoundRect(155, viewH - 145, 270, viewH - 25, 28, 28, paint);
        c.drawRoundRect(viewW - 195, viewH - 145, viewW - 30, viewH - 25, 28, 28, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(52);
        paint.setFakeBoldText(true);
        c.drawText("‹", 60, viewH - 64, paint);
        c.drawText("›", 195, viewH - 64, paint);
        paint.setTextSize(25);
        c.drawText("JUMP", viewW - 173, viewH - 80, paint);
        paint.setFakeBoldText(false);

        paint.setTextSize(16);
        paint.setColor(Color.argb(220, 255, 255, 255));
        if (godMode == GodMode.PLACE) c.drawText("神: ステージをタップ → 足場生成 (-15)", viewW - 400, 112, paint);
        else if (godMode == GodMode.MOVE) c.drawText("神: 水色の足場をドラッグして移動", viewW - 400, 112, paint);
        else c.drawText("神: 赤い敵をタップ → 4秒停止 (-25)", viewW - 400, 112, paint);
    }

    private void drawModeButton(Canvas c, RectF r, String label, boolean selected) {
        paint.setColor(selected ? Color.rgb(53, 188, 244) : Color.argb(200, 24, 51, 75));
        c.drawRoundRect(r, 12, 12, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(selected ? 4 : 2);
        paint.setColor(Color.WHITE);
        c.drawRoundRect(r, 12, 12, paint);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.WHITE);
        paint.setTextSize(20);
        paint.setFakeBoldText(true);
        float tw = paint.measureText(label);
        c.drawText(label, r.centerX() - tw / 2f, r.centerY() + 7, paint);
        paint.setFakeBoldText(false);
    }

    private void drawMenu(Canvas c) {
        paint.setColor(Color.argb(170, 5, 15, 28));
        c.drawRect(0, 0, viewW, viewH, paint);

        paint.setColor(Color.WHITE);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setFakeBoldText(true);
        paint.setTextSize(Math.max(42f, viewH * 0.095f));
        c.drawText("RUNNER + GOD", viewW / 2f, viewH * 0.24f, paint);
        paint.setTextSize(Math.max(20f, viewH * 0.045f));
        c.drawText("1Pが走る。2Pが世界をつくる。", viewW / 2f, viewH * 0.34f, paint);

        paint.setFakeBoldText(false);
        paint.setTextSize(Math.max(17f, viewH * 0.034f));
        c.drawText("1P：左下の ← → と右下の JUMP", viewW / 2f, viewH * 0.45f, paint);
        c.drawText("2P：上の『足場 / 移動 / 停止』を選び、ステージを直接タッチ", viewW / 2f, viewH * 0.51f, paint);
        c.drawText("青い結晶を1Pが取ると、2Pの神力が回復します", viewW / 2f, viewH * 0.57f, paint);

        paint.setColor(Color.rgb(57, 194, 245));
        c.drawRoundRect(startButton, 24, 24, paint);
        paint.setColor(Color.WHITE);
        paint.setFakeBoldText(true);
        paint.setTextSize(Math.max(24f, viewH * 0.048f));
        c.drawText("START", startButton.centerX(), startButton.centerY() + 10, paint);
        paint.setFakeBoldText(false);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private void drawWin(Canvas c) {
        paint.setColor(Color.argb(205, 4, 12, 22));
        c.drawRect(0, 0, viewW, viewH, paint);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setColor(Color.WHITE);
        paint.setFakeBoldText(true);
        paint.setTextSize(Math.max(45f, viewH * 0.10f));
        c.drawText("GOAL!", viewW / 2f, viewH * 0.30f, paint);
        paint.setTextSize(Math.max(21f, viewH * 0.042f));
        long elapsed = SystemClock.elapsedRealtime() - runStartMs;
        c.drawText(String.format("%.1f 秒 / ミス %d 回", elapsed / 1000f, deaths), viewW / 2f, viewH * 0.43f, paint);
        c.drawText("ふたりで、ひとつのステージを攻略しました。", viewW / 2f, viewH * 0.52f, paint);

        paint.setColor(Color.rgb(57, 194, 245));
        c.drawRoundRect(restartButton, 24, 24, paint);
        paint.setColor(Color.WHITE);
        paint.setTextSize(Math.max(23f, viewH * 0.045f));
        c.drawText("もう一度", restartButton.centerX(), restartButton.centerY() + 9, paint);
        paint.setTextAlign(Paint.Align.LEFT);
        paint.setFakeBoldText(false);
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        int action = event.getActionMasked();
        int index = event.getActionIndex();
        int pointerId = event.getPointerId(index);

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            float x = event.getX(index);
            float y = event.getY(index);

            if (state == GameState.MENU) {
                if (startButton.contains(x, y)) {
                    resetLevel();
                    state = GameState.PLAYING;
                }
                return true;
            }
            if (state == GameState.WIN) {
                if (restartButton.contains(x, y)) {
                    resetLevel();
                    state = GameState.PLAYING;
                }
                return true;
            }

            touches.put(pointerId, new PointF(x, y));
            if (modePlace.contains(x, y)) {
                godMode = GodMode.PLACE;
                return true;
            }
            if (modeMove.contains(x, y)) {
                godMode = GodMode.MOVE;
                return true;
            }
            if (modeFreeze.contains(x, y)) {
                godMode = GodMode.FREEZE;
                return true;
            }

            if (!isRunnerControl(x, y) && y > 105 && y < viewH - 165) {
                handleGodDown(pointerId, x, y);
            }
        } else if (action == MotionEvent.ACTION_MOVE) {
            for (int i = 0; i < event.getPointerCount(); i++) {
                int id = event.getPointerId(i);
                PointF p = touches.get(id);
                if (p == null) {
                    p = new PointF();
                    touches.put(id, p);
                }
                p.set(event.getX(i), event.getY(i));
                if (id == draggingPointer && draggingPlatform != null) {
                    float worldX = event.getX(i) + cameraX;
                    float worldY = event.getY(i);
                    draggingPlatform.x = worldX - dragOffsetX;
                    draggingPlatform.y = Math.max(120f, Math.min(viewH - 210f, worldY - dragOffsetY));
                }
            }
        } else if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_POINTER_UP || action == MotionEvent.ACTION_CANCEL) {
            touches.remove(pointerId);
            if (pointerId == draggingPointer) {
                draggingPointer = -1;
                draggingPlatform = null;
            }
            if (action == MotionEvent.ACTION_CANCEL) touches.clear();
        }
        return true;
    }

    private boolean isRunnerControl(float x, float y) {
        return y > viewH - 165f && (x < 300f || x > viewW - 210f);
    }

    private void handleGodDown(int pointerId, float x, float y) {
        float wx = x + cameraX;
        if (godMode == GodMode.PLACE) {
            if (godEnergy < 15f) return;
            int count = 0;
            for (Platform p : platforms) if (p.created) count++;
            if (count >= 5) {
                for (Platform p : platforms) {
                    if (p.created) {
                        platforms.remove(p);
                        break;
                    }
                }
            }
            addPlatform(wx - 75, y - 15, 150, 30, true);
            godEnergy -= 15f;
        } else if (godMode == GodMode.MOVE) {
            for (int i = platforms.size() - 1; i >= 0; i--) {
                Platform p = platforms.get(i);
                if (p.created && wx >= p.x && wx <= p.x + p.w && y >= p.y - 20 && y <= p.y + p.h + 20) {
                    draggingPointer = pointerId;
                    draggingPlatform = p;
                    dragOffsetX = wx - p.x;
                    dragOffsetY = y - p.y;
                    break;
                }
            }
        } else if (godMode == GodMode.FREEZE) {
            if (godEnergy < 25f) return;
            Enemy target = null;
            float best = 60f * 60f;
            for (Enemy e : enemies) {
                float dx = wx - e.x;
                float dy = y - e.y;
                float d = dx * dx + dy * dy;
                if (d < best) {
                    best = d;
                    target = e;
                }
            }
            if (target != null) {
                target.freeze = 4f;
                godEnergy -= 25f;
            }
        }
    }

    private enum GameState { MENU, PLAYING, WIN }
    private enum GodMode { PLACE, MOVE, FREEZE }

    private static class Platform {
        float x, y, w, h;
        final boolean created;
        Platform(float x, float y, float w, float h, boolean created) {
            this.x = x; this.y = y; this.w = w; this.h = h; this.created = created;
        }
    }

    private static class Enemy {
        float x, y, minX, maxX;
        float dir = 1f;
        float freeze = 0f;
        Enemy(float x, float y, float minX, float maxX) {
            this.x = x; this.y = y; this.minX = minX; this.maxX = maxX;
        }
        void update(float dt) {
            if (freeze > 0) {
                freeze -= dt;
                return;
            }
            x += dir * 95f * dt;
            if (x < minX) { x = minX; dir = 1; }
            if (x > maxX) { x = maxX; dir = -1; }
        }
    }

    private static class Crystal {
        final float x, y;
        Crystal(float x, float y) { this.x = x; this.y = y; }
    }
}
