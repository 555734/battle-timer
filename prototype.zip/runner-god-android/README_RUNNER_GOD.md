# Runner + God — Android prototype

A same-device 2-player cooperative 2D side-scroller prototype.

## Player 1 — Runner
- Bottom-left `<` / `>`: move
- Bottom-right `JUMP`: jump
- Collect cyan crystals to refill Player 2's god energy.

## Player 2 — God
Choose one of the buttons at the top right:
- `足場`: tap the stage to create a temporary cyan platform (15 energy)
- `移動`: drag a cyan platform to move it
- `停止`: tap an enemy to freeze it for 4 seconds (25 energy)

God energy regenerates slowly over time. The runner and the god must cooperate to cross gaps, avoid enemies, and reach the flag.

## Build
The `Build Android APK` GitHub Actions workflow builds a debug APK and uploads it as the `runner-god-apk` artifact.
